A Pen created at CodePen.io. You can find this one at https://codepen.io/AndreCortellini/pen/kxwmj.

 A simple JQuery image slider!

Features:
- Automatic slideshow
- Pause on hover
- Dynamic slide counter
- Show/Hide controls on hover